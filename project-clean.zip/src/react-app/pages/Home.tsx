import { useEffect } from 'react';
import { Link } from 'react-router';
import { ArrowRight, Brain, DollarSign, Lightbulb, Users, CheckCircle, Star, MessageCircle } from 'lucide-react';

export default function Home() {
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  }, []);

  const programs = [
    {
      icon: Brain,
      title: "Public Speaking & Communication",
      description: "Build confidence, clarity, and critical thinking through structured speaking practice and peer feedback.",
      features: ["Presentation Skills", "Debate Practice", "Storytelling", "Public Confidence"]
    },
    {
      icon: DollarSign,
      title: "Financial Literacy",
      description: "Empowering students with age-appropriate financial knowledge for lifelong responsibility.",
      features: ["Money Management", "Budgeting Basics", "Investment Fundamentals", "Smart Spending"]
    },
    {
      icon: Lightbulb,
      title: "Innovation & Entrepreneurship",
      description: "Foster creativity, teamwork, and real-world problem-solving through hands-on projects.",
      features: ["Creative Thinking", "Business Planning", "Problem Solving", "Team Collaboration"]
    }
  ];

  const stats = [
    { number: "100%", label: "Satisfaction Rate" },
    { number: "3", label: "Skilled Expert Instructors" },
    { number: "24/7", label: "Support Available" }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-slate-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-blue-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-1000"></div>
          <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-gray-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-2000"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold bg-gradient-to-r from-slate-400 via-blue-500 to-blue-400 bg-clip-text text-transparent leading-tight">
                Quantum Learning
              </h1>
              <p className="text-xl sm:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                Innovative special skills education through Public Speaking, Financial Literacy, and Innovation programs
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link 
                to="/schedule"
                className="group inline-flex items-center px-8 py-4 bg-gradient-to-r from-slate-700 to-blue-600 text-white font-semibold rounded-full hover:from-slate-800 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                Schedule Consultation
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/pricing"
                className="inline-flex items-center px-8 py-4 border-2 border-slate-400 text-slate-400 font-semibold rounded-full hover:bg-slate-400 hover:text-white transition-all duration-300"
              >
                View Pricing
              </Link>
            </div>

            <div className="flex justify-center items-center space-x-8 text-gray-400">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-2xl font-bold text-white">{stat.number}</div>
                  <div className="text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Programs Section */}
      <section className="py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-5xl font-bold text-center mb-12">Our Core Programs</h2>
          <div className="grid md:grid-cols-3 gap-12">
            {programs.map((program, index) => (
              <div key={index} className="bg-slate-800 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition">
                <program.icon className="w-12 h-12 text-blue-400 mb-4" />
                <h3 className="text-2xl font-semibold mb-4">{program.title}</h3>
                <p className="text-gray-300 mb-6">{program.description}</p>
                <ul className="space-y-2 text-gray-400">
                  {program.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center">
                      <CheckCircle className="w-4 h-4 mr-2 text-blue-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-slate-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-5xl font-bold mb-12">What Our Families Say</h2>
          <div className="space-y-12">
            <blockquote className="bg-slate-900 p-8 rounded-2xl shadow-lg">
              <Star className="mx-auto w-8 h-8 text-blue-400 mb-4" />
              <p className="text-gray-300 mb-6 leading-relaxed">
                "Both of my children were fully engaged and excited throughout the class. The instructor made even difficult topics clear and relatable, while keeping the session interactive and fun."
              </p>
              <footer className="text-gray-400 font-semibold">— Shefali Sarangal, Parent</footer>
            </blockquote>
            <blockquote className="bg-slate-900 p-8 rounded-2xl shadow-lg">
              <Star className="mx-auto w-8 h-8 text-blue-400 mb-4" />
              <p className="text-gray-300 mb-6 leading-relaxed">
                "Both of my children loved Quantum Learning. The classes were engaging, interactive, and made even challenging topics clear and fun."
              </p>
              <footer className="text-gray-400 font-semibold">— Mukul Pal, Parent</footer>
            </blockquote>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-slate-900 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold mb-6">
          Ready to Transform Your Learning Journey?
        </h2>
        <p className="text-lg text-gray-300 mb-10 max-w-2xl mx-auto">
          Join thousands of students who have discovered their potential through our innovative programs.
        </p>
        <div className="flex justify-center gap-6">
          <Link to="/schedule" className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 shadow-lg transition">
            Get Started Today
          </Link>
          <Link to="/about" className="px-6 py-3 bg-gray-200 text-gray-900 rounded-lg font-semibold hover:bg-gray-300 shadow-md transition">
            Learn More About Us
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t border-gray-700 text-center text-gray-400 text-sm">
        © {new Date().getFullYear()} Quantum Learning. All rights reserved.
      </footer>

      {/* Floating Chat Button (disabled) */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-center">
        <div className="relative">
          {/* Coming Soon Banner */}
          <div className="absolute -top-3 -right-3 bg-red-600 text-white text-xs font-bold px-2 py-0.5 rounded-full shadow-md animate-pulse">
            Coming Soon
          </div>
          <button
            disabled
            className="bg-gradient-to-r from-slate-700 to-blue-600 text-white p-4 rounded-full shadow-lg opacity-70 cursor-not-allowed"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
}

