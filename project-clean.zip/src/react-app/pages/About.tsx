import { useEffect } from "react";
import { Target, Users, Award, Globe, CheckCircle } from "lucide-react";

export default function About() {
  useEffect(() => {
    const link = document.createElement("link");
    link.href =
      "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap";
    link.rel = "stylesheet";
    document.head.appendChild(link);
  }, []);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-slate-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-6xl font-bold bg-gradient-to-r from-slate-400 to-blue-500 bg-clip-text text-transparent mb-6">
            About Quantum Learning
          </h1>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto leading-relaxed">
            We're revolutionizing education by combining proven pedagogical
            methods with innovative technology to create transformative learning
            experiences that prepare students for success in the 21st century.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-black/20 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Our Story</h2>
          <p className="text-gray-300 leading-relaxed">
            Quantum Learning was born from a simple observation: traditional
            education often leaves critical life skills untaught. Students
            graduate without knowing how to speak confidently in public, manage
            their finances, or think innovatively about solving real-world
            problems.
          </p>
          <p className="text-gray-300 leading-relaxed mt-4">
            Founded in 2025 by a team of educators, entrepreneurs, and child
            development experts, we set out to bridge this gap. Our
            comprehensive programs focus on the three pillars essential for
            modern success: communication, financial literacy, and innovation.
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Our Values
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Target,
                title: "Mission-Driven",
                desc: "We're committed to fostering confidence, creativity, and critical thinking in tomorrow's leaders through innovative education.",
              },
              {
                icon: Users,
                title: "Student-Centered",
                desc: "Every program is designed with the student's growth, engagement, and success as the primary focus.",
              },
              {
                icon: Award,
                title: "Excellence in Education",
                desc: "Our expert instructors bring years of experience and proven methodologies to each learning session.",
              },
              {
                icon: Globe,
                title: "Globally Accessible",
                desc: "Virtual programs that break down geographical barriers and make quality education available worldwide.",
              },
            ].map((value, i) => {
              const Icon = value.icon;
              return (
                <div
                  key={i}
                  className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10 text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-slate-600 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-6">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">
                    {value.title}
                  </h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {value.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 bg-black/20 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Our Leadership Team
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Krishnav */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
              <h3 className="text-xl font-bold text-white mb-2">
                Krishnav Gudepu
              </h3>
              <p className="text-sm text-gray-400 mb-4">
                Public Speaking & Communication Skills, Student Educator
              </p>
              <p className="text-gray-300 text-sm leading-relaxed">
                Krishnav Gudepu is the founder of Quantum Learning. He started
                this initiative to help students in grades 2–8 develop the
                real-world skills that matter most: public speaking, financial
                literacy, and innovation. His passion lies in creating engaging
                and practical learning experiences that go beyond traditional
                academics. Through Quantum Learning, he combines live classes
                and self-paced learning with interactive projects, showcases,
                and activities that make learning exciting and impactful.
                Krishnav has been deeply involved in leadership, community
                service, and STEM innovation, and he brings those experiences
                into his teaching. His goal is to empower students to build
                confidence, think creatively, and develop the skills they need
                not just for school, but for life.
              </p>
            </div>

            {/* Ushnish */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
              <h3 className="text-xl font-bold text-white mb-2">
                Ushnish Ghosh
              </h3>
              <p className="text-sm text-gray-400 mb-4">
                Financial Literacy & Youth Education
              </p>
              <p className="text-gray-300 text-sm leading-relaxed">
                Ushnish Ghosh is a cofounder and head instructor at Quantum
                Learning with a strong focus on financial literacy. He believes
                every child should gain essential money skills like budgeting,
                saving, and responsible spending through practical lessons that
                are easy to understand. Ushnish is passionate about creating
                interactive learning experiences that give students confidence
                in managing their own finances. Beyond the classroom, he has
                worked on community youth programs that make financial concepts
                accessible and engaging. His approach blends real-world
                applications with hands-on activities, ensuring students not
                only learn the principles but know how to apply them in their
                daily lives. By bringing enthusiasm and clarity to every
                session, Ushnish helps young learners build financial skills
                that will benefit them for a lifetime.
              </p>
            </div>

            {/* Kaustav */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg rounded-2xl p-6 border border-white/10">
              <h3 className="text-xl font-bold text-white mb-2">
                Kaustav Ghosh
              </h3>
              <p className="text-sm text-gray-400 mb-4">
                Innovation & Creative Problem-Solving
              </p>
              <p className="text-gray-300 text-sm leading-relaxed">
                From a young age, Kaustav has been fascinated by how people
                approach challenges differently and create unique solutions. His
                passion for innovative thinking has been shaped not only by his
                involvement in organizations like FBLA, DECA, and Model United
                Nations, but also through pursuits in music, sports, and
                entrepreneurship. Whether drumming with his band, composing
                music, or boxing, Kaustav has learned that innovation thrives
                when discipline meets imagination. As a co-owner of a dog-sitting
                business, he has also gained real-world experience in customer
                service, management, and problem-solving. With a Google
                certification in website design, Kaustav brings a creative yet
                practical perspective to education. At Quantum Learning, he
                empowers students to think differently, solve problems
                effectively, and embrace resilience in their own journeys.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

