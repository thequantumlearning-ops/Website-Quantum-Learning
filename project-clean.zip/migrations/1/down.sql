
DROP TABLE appointments;
DROP TABLE chat_sessions;
